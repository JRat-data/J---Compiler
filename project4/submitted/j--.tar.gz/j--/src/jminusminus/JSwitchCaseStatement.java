// HW3 Problem 4 Switch
package jminusminus;
import static jminusminus.CLConstants.*;

class JSwitchCaseStatement extends JStatement {

    private JStatement case_body;
    private JExpression case_label;

    public JSwitchCaseStatement(int line, JExpression case_label, JStatement case_body) {
        super(line);
        this.case_label = case_label;
        this.case_body = case_body;
    }

    public JSwitchCaseStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
