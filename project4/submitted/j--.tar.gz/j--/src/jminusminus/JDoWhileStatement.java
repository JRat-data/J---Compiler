// HW3 Problem 5 Do-While (Based off JWhileStatement)
package jminusminus;

import static jminusminus.CLConstants.*;

class JDoWhileStatement extends JStatement {

    private JStatement body;
    private JExpression condition;

    public JDoWhileStatement(int line, JStatement body, JExpression condition) {
        super(line);
        this.body = body;
        this.condition = condition;
    }

    public JDoWhileStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
       
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
