// HW3 Problem 7 Throw
package jminusminus;
import static jminusminus.CLConstants.*;

class JThrowStatement extends JStatement {
    
    private JExpression expr;
        
    public JThrowStatement(int line, JExpression expr) {
        super(line);
        this.expr = expr;
    }

    public JThrowStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
