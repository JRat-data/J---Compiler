// HW3 Problem 7 Try, Catch, Finally
package jminusminus;
import static jminusminus.CLConstants.*;

class JFinallyStatement extends JStatement {
    
    private JBlock finally_block;
        
    public JFinallyStatement(int line, JBlock finally_block) {
        super(line);
        this.finally_block = finally_block;
    }

    public JFinallyStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
