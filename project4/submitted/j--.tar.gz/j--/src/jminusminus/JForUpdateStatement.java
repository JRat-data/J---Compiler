// HW3 Problem 6 For 
package jminusminus;
import static jminusminus.CLConstants.*;

class JForUpdateStatement extends JStatement {

    private JVariableDeclarator init;
    private JExpression array;
    private JBlock body;

    public JForUpdateStatement(int line, JVariableDeclarator init, 
            JExpression array, JBlock body) {
        super(line);
        this.init = init;
        this.array = array;
        this.body = body;
    }

    public JForUpdateStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
