/**
 * MultiLineComment.java: tets the implementation of multi-line comment.
 */

public class MultiLineComment {
    /**
     * Entry point.
     */
    public static void main(String[] args) {
        /** This method does absolutely nothing, so is 
            utterly pointless.
        **/
    } 
}
