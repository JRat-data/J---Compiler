// HW3 Problem 2 Added LessThan comparison
package jminusminus;

import static jminusminus.CLConstants.*;

class JLessThanOp extends JComparison {

    public JLessThanOp(int line, JExpression lhs, JExpression rhs) {
        super(line, "<", lhs, rhs);
    }

    public void codegen(CLEmitter output, String targetLabel, boolean onTrue) {
        lhs.codegen(output);
        rhs.codegen(output);
        
        output.addBranchInstruction(onTrue ? IF_ICMPLT : IF_ICMPGE,
                        targetLabel);
    }

}
