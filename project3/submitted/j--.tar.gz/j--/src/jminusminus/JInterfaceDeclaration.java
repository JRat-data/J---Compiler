// HW3 Problem 8 InterfaceDeclaration based on Class Declaration
package jminusminus;

import java.util.ArrayList;
import static jminusminus.CLConstants.*;

class JInterfaceDeclaration extends JAST implements JTypeDecl {

    private ArrayList<String> mods;
    private String name;
    private ArrayList<TypeName> superClasses;
    private ArrayList<JMember> interfaceBlock;
    
    public JInterfaceDeclaration(int line, ArrayList<String> mods, String name,
            ArrayList<TypeName> classes, ArrayList<JMember> interfaceBlock) {
        super(line);
        this.mods = mods;
        this.name = name;
        this.superClasses = superClasses;
        this.interfaceBlock = interfaceBlock;
    }

    public String name() {
        return name;
    }

    public Type superType() {
        return null;
    }

    public Type thisType() {
        return null;
    }

    public ArrayList<JFieldDeclaration> instanceFieldInitializations() {
        return null;
    }

    public void declareThisType(Context context) {
        
    }

    public void preAnalyze(Context context) {
        
    }

    public JAST analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

    private void codegenPartialImplicitConstructor(CLEmitter partial) {
        
    }


    private void codegenImplicitConstructor(CLEmitter output) {
        
    }

    private void codegenClassInit(CLEmitter output) {
        
    }

}
