// HW3 Problem 6 For 
package jminusminus;
import static jminusminus.CLConstants.*;

class JForStatement extends JStatement {
    
    private JStatement initial;
    private JExpression test;
    private JExpression update;
    private JStatement consequent;
        
    public JForStatement(int line, JStatement initial, JExpression test, 
            JExpression update, JStatement consequent) {
        super(line);
        this.initial = initial;
        this.test = test;
        this.update = update;
        this.consequent = consequent;
    }

    public JForStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
