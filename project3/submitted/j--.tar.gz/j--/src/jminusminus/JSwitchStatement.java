// HW3 Problem 4 Switch
package jminusminus;
import static jminusminus.CLConstants.*;

class JSwitchStatement extends JStatement {

    private JBlock body;
    private JExpression test;

    public JSwitchStatement(int line, JExpression test, JBlock body) {
        super(line);
        this.test = test;
        this.body = body;
    }

    public JSwitchStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
