// HW3 Added default for Problem 4 
package jminusminus;
import static jminusminus.CLConstants.*;

class JSwitchDefaultStatement extends JStatement {

    private JStatement case_body;

    public JSwitchDefaultStatement(int line, JStatement case_body) {
        super(line);
        this.case_body = case_body;
    }

    public JSwitchDefaultStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
