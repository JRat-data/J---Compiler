// HW3 Problem 7 Try, Catch, Finally
package jminusminus;
import static jminusminus.CLConstants.*;

class JCatchStatement extends JStatement {
    
    private JFormalParameter catch_par;
    private JStatement catch_state;
        
    public JCatchStatement(int line, JFormalParameter catch_par, 
            JStatement catch_state) {
        super(line);
        this.catch_par = catch_par;
        this.catch_state = catch_state;
    }

    public JCatchStatement analyze(Context context) {
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
