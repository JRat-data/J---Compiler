// Multiline Comment test
import java.lang.System;

/**
 * useless comment 1.
 */
public class MultiLineCommentX {

    /**
     * useless comment 2.
     *
     * @param args  the command-line arguments
     */
    public static void main(String[] args) {
        /**
         * useless comment 3.
         * 
         ** /
         *
         * // useless 
         * /*
         * 
         * * /
         * {@code 1 * 2 / 3}
         **/
        System.out.println(1/1);
        System.out.println(1*1);
        System.out.println(1/1);
        System.out.println(1*1);
        
    }

    /**
        useless comment 4.
     **/
}

/************************
 * last useless comment.
 ***********************/
