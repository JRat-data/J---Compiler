// HW3 Problem 7 Try, Catch, Finally
package jminusminus;
import static jminusminus.CLConstants.*;

class JFinallyStatement extends JStatement {
    
    private JBlock finally_block;
        
    public JFinallyStatement(int line, JBlock finally_block) {
        super(line);
        this.finally_block = finally_block;
    }

    public JFinallyStatement analyze(Context context) {
        finally_block.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }
    
    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JFinallyStatement line=\"%d\">\n", line());
        p.printf("<Block>\n");
        p.indentRight();
        finally_block.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Block>\n");
        p.printf("</JFinallyStatement>\n");
    }

}
