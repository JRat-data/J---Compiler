// HW3 Problem 7 Try, Catch, Finally
package jminusminus;
import static jminusminus.CLConstants.*;

class JTryStatement extends JStatement {
    
    private JStatement try_state;
    private JFormalParameter catch_par;
    private JBlock catch_body;
    private JStatement finally_state;
        
    public JTryStatement(int line, JStatement try_state, JFormalParameter catch_par, 
            JBlock catch_body, JStatement finally_state) {
        super(line);
        this.try_state = try_state;;
        this.catch_par = catch_par;
        this.catch_body = catch_body;
        this.finally_state = finally_state;
    }

    public JTryStatement analyze(Context context) {
        try_state.analyze(context);
        catch_par.analyze(context);
        if(catch_par instanceof JFormalParameter) {
            catch_body.analyze(context);
        }
        if(finally_state != null) {
            finally_state.analyze(context);
        }
        return this;
    }

    public void codegen(CLEmitter output) {
        try_state.codegen(output);
        catch_par.codegen(output);
        if(catch_body != null) {
            catch_body.codegen(output);
        }
        if(finally_state != null) {
            finally_state.codegen(output);
        }
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JTryStatement line=\"%d\">\n", line());
        p.printf("<TryStatement>\n");
        p.indentRight();
        try_state.writeToStdOut(p);
        p.indentLeft();
        p.printf("</TryStatement>\n");
        
        p.printf("<CatchParameter>\n");
        p.indentRight();
        catch_par.writeToStdOut(p);
        p.indentLeft();
        p.printf("</CatchParameter>\n");
        
        p.printf("<CatchBody>\n");
        p.indentRight();
        catch_body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</CatchBody>\n");
        
        if (finally_state != null) {
            p.printf("<FinallyStatement>\n");
            p.indentRight();
            finally_state.writeToStdOut(p);
            p.indentLeft();
            p.printf("</FinallyStatement>\n");
        }
        
        p.printf("</JTryStatement>");
    }

}
