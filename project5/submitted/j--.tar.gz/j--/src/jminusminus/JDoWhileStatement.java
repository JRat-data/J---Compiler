// HW3 Problem 5 Do-While (Based off JWhileStatement)
package jminusminus;

import static jminusminus.CLConstants.*;

class JDoWhileStatement extends JStatement {

    private JStatement body;
    private JExpression condition;

    public JDoWhileStatement(int line, JStatement body, JExpression condition) {
        super(line);
        this.body = body;
        this.condition = condition;
    }

    public JDoWhileStatement analyze(Context context) {
        // HW5 Problem 5
        condition = condition.analyze(context);
        condition.type().mustMatchExpected(line(), Type.BOOLEAN);
        body = (JStatement) body.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
       // HW5 Problem 5
        String in_test = output.createLabel();
        String main_bod = output.createLabel();
        String out_test = output.createLabel();
        output.addLabel(main_bod);
        body.codegen(output);
        output.addLabel(in_test);
        condition.codegen(output, out_test, false);
        output.addBranchInstruction(GOTO, main_bod);
        output.addLabel(out_test);
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JDoWhileStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<Body>\n");
        p.indentRight();
        body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Body>\n");
        p.printf("<Condition>\n");
        p.indentRight();
        condition.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Condition>\n");
        p.indentLeft();
        p.printf("</JDoWhileStatement>\n");
    }

}
