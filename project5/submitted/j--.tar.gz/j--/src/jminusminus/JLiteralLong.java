// HW3 Problem 1 Long

/* For this file, I used JLiteralInt as a model and
 * looked in the book for LCONST to for the number of cases needed
 */

package jminusminus;

import static jminusminus.CLConstants.*;

class JLiteralLong extends JExpression {

    private String text;

    public JLiteralLong(int line, String text) {
        super(line);
        this.text = text;
    }

    public JExpression analyze(Context context) {
        type = Type.LONG;
        return this;
    }
    
    // HW5 Problem 1
    public void codegen(CLEmitter output) {
        String s = text.substring(0, text.length() - 1);
        long i = Long.parseLong(s);
        if (i == 0L) {
            output.addNoArgInstruction(LCONST_0);
        } else if (i == 1L) {
            output.addNoArgInstruction(LCONST_1);
        } else {
            output.addLDCInstruction(i);
        }
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JLiteralLong line=\"%d\" type=\"%s\" " + "value=\"%s\"/>\n",
                line(), ((type == null) ? "" : type.toString()), text);
    }
}

