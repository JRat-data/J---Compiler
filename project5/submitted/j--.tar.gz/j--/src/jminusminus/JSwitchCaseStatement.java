// HW3 Problem 4 Switch
package jminusminus;
import static jminusminus.CLConstants.*;
import java.util.ArrayList;

//HW5 Modified
class JSwitchCaseStatement extends JStatement {
    
    private JExpression case_expr;
    private ArrayList<JStatement> case_body;

    public JSwitchCaseStatement(int line, JExpression case_expr, 
                                ArrayList<JStatement>  case_body) {
        super(line);
        this.case_expr = case_expr;
        this.case_body = case_body;
    }

    public JSwitchCaseStatement analyze(Context context) {
        case_expr = (JExpression) case_expr.analyze(context);
        case_expr.type().mustMatchExpected(line(), Type.INT);
        for (JStatement c : case_body) {
            c = (JStatement) c.analyze(context);
        }
        return this;
    }

    public JExpression getTest() {
        return case_expr;
    }
    
    public void codegen(CLEmitter output) {
        for (JStatement c : case_body) {
            c.codegen(output);
        }
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JSwitchCaseStatement line=\"%d\">\n", line());
        p.printf("<CaseExpression>\n");
        p.indentRight();
        case_expr.writeToStdOut(p);
        p.indentLeft();
        p.printf("</CaseExpression>\n");
        p.printf("<CaseBody>\n");
        p.indentRight();
        for (JStatement c : case_body) {
            c.writeToStdOut(p);
        }
        p.indentLeft();
        p.printf("</CaseBody>\n");
        p.printf("</JSwitchCaseStatement>\n");
    }

}
