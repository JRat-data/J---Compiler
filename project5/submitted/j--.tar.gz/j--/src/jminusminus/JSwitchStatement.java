// HW3 Problem 4 Switch
package jminusminus;
import static jminusminus.CLConstants.*;
import java.util.ArrayList;

class JSwitchStatement extends JStatement {

    private JExpression test;
    private ArrayList<JStatement> cases;

    public JSwitchStatement(int line, JExpression test, ArrayList<JStatement> cases) {
        super(line);
        this.test = test;
        this.cases = cases;
    }

    public JSwitchStatement analyze(Context context) {
        test = (JExpression) test.analyze(context);
        test.type().mustMatchExpected(line(), Type.INT);
        for (JStatement c : cases) {
            c = (JStatement) c.analyze(context);
        }
        return this;
    }

    public void codegen(CLEmitter output) {
        String end = output.createLabel();
        String[] pars = new String[cases.size()];
        for(int i = 0; i < pars.length; i++) {
            pars[i] = output.createLabel();
        }
        for (int i = 0; i < pars.length; i++) {
            if(cases.get(i) instanceof JSwitchCaseStatement) {
                test.codegen(output);
                ((JSwitchCaseStatement)(cases.get(i))).getTest().codegen(output);
                output.addBranchInstruction(IF_ICMPEQ, pars[i]);
            } else {
                output.addBranchInstruction(GOTO, pars[i]);
                break;
            }
        }
        for(int i = 0; i < pars.length; i++) {
            output.addLabel(pars[i]);
            cases.get(i).codegen(output);
        }
        output.addLabel(end);
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JSwitchStatmenet line = \"%d\">\n", line());
        p.indentRight();
        p.printf("<Expression>\n");
        test.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Expression>\n");
        p.indentRight();
        p.printf("<Cases>\n");
        for (JStatement c : cases) {
            c.writeToStdOut(p);
        }
        p.indentLeft();
        p.printf("</Cases>\n");
        p.printf("</SwitchStatement>\n");
    }

}
