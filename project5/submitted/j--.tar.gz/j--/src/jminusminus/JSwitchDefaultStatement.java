// HW3 Added default for Problem 4 
package jminusminus;
import static jminusminus.CLConstants.*;

class JSwitchDefaultStatement extends JStatement {

    private JStatement def_body;

    public JSwitchDefaultStatement(int line, JStatement def_body) {
        super(line);
        this.def_body = def_body;
    }

    public JSwitchDefaultStatement analyze(Context context) {
        def_body.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JSwitchDefaultStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<DefaultBody>\n");
        def_body.writeToStdOut(p);
        p.printf("</DefaultBody>\n");
        p.indentLeft();
        p.printf("</JSwitchDefaultStatement>\n");
    }

}
