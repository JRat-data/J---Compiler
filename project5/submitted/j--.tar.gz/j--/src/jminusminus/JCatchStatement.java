// HW3 Problem 7 Try, Catch, Finally
package jminusminus;
import static jminusminus.CLConstants.*;

class JCatchStatement extends JStatement {
    
    private JFormalParameter catch_par;
    private JBlock catch_body;
        
    public JCatchStatement(int line, JFormalParameter catch_par, 
            JBlock catch_body) {
        super(line);
        this.catch_par = catch_par;
        this.catch_body = catch_body;
    }

    public JCatchStatement analyze(Context context) {
        catch_par.analyze(context);
        catch_body.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        catch_par.codegen(output);
        catch_body.codegen(output);
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JCatchStatement line=\"%d\">\n", line());
        p.printf("<FormalParameter>\n");
        p.indentRight();
        catch_par.writeToStdOut(p);
        p.indentLeft();
        p.printf("</FormalParameter>\n");
        p.printf("<Body>\n");
        p.indentRight();
        catch_body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Body>\n");
        p.printf("</JCatchStatement>");
    }

}
