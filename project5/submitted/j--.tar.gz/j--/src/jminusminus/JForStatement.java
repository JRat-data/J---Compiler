// HW3 Problem 6 For 
package jminusminus;
import static jminusminus.CLConstants.*;

class JForStatement extends JStatement {
    
    private JVariableDeclaration initial;
    private JExpression test;
    private JStatement update;
    private JStatement consequent;
        
    public JForStatement(int line, JVariableDeclaration initial, JExpression test, 
            JStatement update, JStatement consequent) {
        super(line);
        this.initial = initial;
        this.test = test;
        this.update = update;
        this.consequent = consequent;
    }

    public JForStatement analyze(Context context) {
        // HW5 Problem 6
        initial.analyze(context);
        test.analyze(context);
        test.type().mustMatchExpected(line(), Type.BOOLEAN);
        if (update != null) {
            update.analyze(context);
        }
        consequent.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        // HW5 Problem 6
        String in_test = output.createLabel();
        String out_test = output.createLabel();
        output.addLabel(in_test);
        test.codegen(output, out_test, false);
        consequent.codegen(output);
        update.codegen(output);
        output.addBranchInstruction(GOTO, in_test);
        output.addLabel(out_test);
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JForStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<Test>\n");
        p.indentRight();
        test.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Test>\n");
        p.printf("<Consequent>\n");
        p.indentRight();
        consequent.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Consequent>\n");
        p.indentLeft();
        p.printf("</JForStatement>\n");
    }

}
