// HW3 Added file
package jminusminus;

import static jminusminus.CLConstants.*;

class JBreakStatement extends JStatement {

    public JBreakStatement(int line) {
        super(line);
    }

    public JAST analyze (Context context) {
        return this;
    }
    
    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        
    }

}
