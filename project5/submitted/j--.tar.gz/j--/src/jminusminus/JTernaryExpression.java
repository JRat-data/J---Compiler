// HW3 Problem 3 Ternary Expression for Question OP
// Based on JBinaryExpression

package jminusminus;

import static jminusminus.CLConstants.*;

abstract class JTernaryExpression extends JExpression {
    
    protected String operator;
    protected String separator;

    protected JExpression e1; // condition
    protected JExpression e2; 
    protected JExpression e3; 

    protected JTernaryExpression(int line, String operator, String separator, 
            JExpression e1, JExpression e2, JExpression e3) {
        super(line);
        this.operator = operator;
        this.separator = separator;
        this.e1 = e1;
        this.e2 = e2;
        this.e3 = e3;
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JTernaryExpression line=\"%d\" type=\"%s\" "
                + "operator=\"%s\">\n", line(), ((type == null) ? "" : type
                .toString()), Util.escapeSpecialXMLChars(operator));
        p.indentRight();
        p.printf("<e1>\n");
        p.indentRight();
        e1.writeToStdOut(p);
        p.indentLeft();
        p.printf("</e1\n");
        
        p.printf("<e2>\n");
        p.indentRight();
        e2.writeToStdOut(p);
        p.indentLeft();
        
        p.printf("</e2>\n");
        p.printf("<e3>\n");
        p.indentRight();
        e3.writeToStdOut(p);
        p.indentLeft();
        
        p.printf("</e3>\n");
        p.indentLeft();
        p.printf("</JTernaryExpression>\n");
    }

}

class JTernaryOp extends JTernaryExpression {
    
    public JTernaryOp(int line, JExpression e1, JExpression e2, JExpression e3) {
        super(line, "?", ":", e1, e2, e3);
    }
    
    public JExpression analyze (Context context) { 
        // HW5 Modified Problem 3
        e1 = (JExpression) e1.analyze(context);
        e1.type().mustMatchExpected(line(), Type.BOOLEAN);
        e2 = (JExpression) e2.analyze(context);
        e3 = (JExpression) e3.analyze(context);
        e2.type().mustMatchExpected(line(), e3.type());
        type = e2.type();
        return this;
    }
    
    // HW5 Modified Problem 3
    public void codegen(CLEmitter output) {
        String elseLabel = output.createLabel();
        String endLabel = output.createLabel();
        e1.codegen(output, elseLabel, false);
        e2.codegen(output);
        output.addBranchInstruction(GOTO, endLabel);
        output.addLabel(elseLabel);
        e3.codegen(output);
        output.addLabel(endLabel);
    }
}

