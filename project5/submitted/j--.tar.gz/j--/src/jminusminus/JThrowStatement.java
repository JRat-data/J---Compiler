// HW3 Problem 7 Throw
package jminusminus;
import static jminusminus.CLConstants.*;

class JThrowStatement extends JStatement {
    
    private JExpression expr;
        
    public JThrowStatement(int line, JExpression expr) {
        super(line);
        this.expr = expr;
    }

    public JThrowStatement analyze(Context context) {
        expr.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JThrowStatement line=\"%d\">\n", line());
        p.printf("<Expression>\n");
        p.indentRight();
        expr.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Expression>\n");
        p.printf("</JThrowStatement>\n");
    }

}
