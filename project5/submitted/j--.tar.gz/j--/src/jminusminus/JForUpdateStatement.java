// HW3 Problem 6 For 
package jminusminus;
import static jminusminus.CLConstants.*;

class JForUpdateStatement extends JStatement {

    private JVariableDeclaration init;
    private JExpression array;
    private JStatement body;

    public JForUpdateStatement(int line, JVariableDeclaration init, 
            JExpression array, JStatement body) {
        super(line);
        this.init = init;
        this.array = array;
        this.body = body;
    }

    public JForUpdateStatement analyze(Context context) {
        // HW5 Problem 6
        init.analyze(context);
        array.analyze(context);
        body.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
        // HW5 Problem 6 copied from ForStatement
        String in_test = output.createLabel();
        String out_test = output.createLabel();
        output.addLabel(in_test);
        init.codegen(output);
        array.codegen(output, out_test, false);
        body.codegen(output);
        output.addBranchInstruction(GOTO, in_test);
        output.addLabel(out_test);
    }

    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JForUpdateStatement line=\"%d\">\n", line());
        p.indentRight();
        p.printf("<Init>\n");
        p.indentRight();
        init.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Init>\n");
        p.printf("<Array>\n");
        p.indentRight();
        array.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Array>\n");
        p.indentLeft();
        p.printf("<Body>\n");
        p.indentRight();
        body.writeToStdOut(p);
        p.indentLeft();
        p.printf("</Body>\n");
        p.indentLeft();
        p.printf("</JForStatement>\n");
    }

}
